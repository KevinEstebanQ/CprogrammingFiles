/*
 * sortMenu()
 * 
 * OBJECTIVE: Sort menu items using function pointer for comparison strategy
 *            Demonstrate advanced function pointer concepts with dynamic data selection
 * 
 * PARAMETERS:
 * - names[][MAX_NAME_LENGTH]: 2D array of item names
 * - categories[][MAX_CATEGORY_LENGTH]: 2D array of categories
 * - prices: 1D array of prices (float*)
 * - count: number of items to sort
 * - 💡compare: function pointer for comparison strategy
 * 
 * RETURNS: void (arrays are sorted in-place)
 * 
 * REQUIREMENTS:
 * - Sort all three arrays simultaneously to maintain data consistency
 * - 💡Use function pointer array to identify which comparison function was passed
 * - Dynamically select appropriate data (prices, names, or categories) for comparison
 * - Implement a sorting algorithm with loop safety protection
 * - Handle edge cases and invalid input appropriately
 * - Keep related data together across all arrays
 * 
 * 💡ADVANCED FUNCTION POINTER CONCEPTS:
 * - Function pointer identity comparison for strategy detection
 * - Function pointer arrays for mapping strategies to behaviors
 * - Dynamic data selection based on function pointer analysis
 * - Strategy pattern implementation with function pointers
 * 
 * SORTING CONCEPTS:
 * - Multi-array sorting maintaining data relationships
 * - In-place sorting algorithm implementation
 * - Comparison-based sorting logic
 * 
 * LOOP SAFETY CONCEPTS:
 * - Infinite loop protection using iteration counters
 * - Breaking out of nested loops when safety limits exceeded
 * - Maximum iteration limits for safety
 * 
 * 👍USE AVAILABLE COMPARISON FUNCTIONS (from driver):
 * - compareByName: sorts alphabetically by item name
 * - compareByPrice: sorts numerically by price (ascending)
 * - compareByCategory: sorts alphabetically by category
 * 
 * RELEVANT CONSTANTS:
 * - MAX_LOOP_ITERATIONS: Maximum allowed loop iterations for safety
 * - MAX_NAME_LENGTH, MAX_CATEGORY_LENGTH: For safe string operations
 */

#include "restaurant.h"

void sortMenu(char names[][MAX_NAME_LENGTH], 
             char categories[][MAX_CATEGORY_LENGTH],
             float* prices, int count, CompareFunction compare) {
    
    // TODO: Implement sorting with advanced function pointer array technique
    //
    // 1. INPUT VALIDATION:
    //    - Check all array pointers for NULL
    //    - Check function pointer for NULL
    //    - Check if sorting is needed (count > 1)
    //    - Return early if validation fails
    //
    // 2. 💡FUNCTION POINTER STRATEGY DETECTION:
    //    - Create function pointer array containing available comparison functions from the driver
    //    - Compare the passed function pointer with known comparison functions from the driver
    //    - Determine which data type to use for comparison (prices, names, categories)
    //    - Handle unknown function pointer appropriately
    //
    // 3. INITIALIZE VARIABLES:
    //    - Declare counter variable for loop safety protection
    //    - Initialize appropriately
    //
    // 4. IMPLEMENT SORTING ALGORITHM WITH DYNAMIC DATA SELECTION:
    //    - Choose and implement a sorting algorithm of your preference
    //    - Implement safety check: increment counter for each comparison/iteration
    //    - Break loops if counter exceeds MAX_LOOP_ITERATIONS
    //    - Use appropriate data for comparison based on detected function pointer
    //    - Call comparison function with correct data type (prices, names, or categories)
    //
    // 5. PERFORM SWAPPING:
    //    - When elements need reordering, swap corresponding elements in ALL arrays
    //    - Use strncpy() for safe string swapping
    //    - Use temporary variables for swapping operations
    //
    // 🎯Advanced Function Pointer Tips:
    // - Create array: CompareFunction strategies[] = {compareByPrice, compareByName, compareByCategory};
    // - Compare pointers: if (compare == strategies[i]) { /* use corresponding data */ }
    // - Use different data for each strategy: prices for compareByPrice, names for compareByName, etc.
    //
    // Algorithm Choice: You may implement bubble sort, selection sort, insertion sort,
    // or any other sorting algorithm you prefer. Focus on correctness and safety.
    //
    // String Safety Tip: Use strncpy() for string copying during swaps
    // Safety Tip: Check loop counter against MAX_LOOP_ITERATIONS constant
    
    // Your implementation here:

    if(!names || !categories || !prices || !compare || count <=0 ){
        return;
    } // input validation

    CompareFunction Strategies[] = {compareByPrice, compareByName, compareByCategory};

     enum { BY_PRICE, BY_NAME, BY_CATEGORY, BY_UNKNOWN } mode = BY_UNKNOWN;
     if(compare == Strategies[0]) mode = BY_PRICE;
     if(compare == Strategies[1]) mode = BY_NAME;
     if(compare == Strategies[2]) mode = BY_CATEGORY;
     else mode = BY_NAME;

     int iterations = 0; // counter for iteratios to not go over limit
     int exceeded = 0; // flag to stop iteration
     for (int i = 0; i < count - 1 && !exceeded; i++){
        for (int j = 0; j < count - 1; j++){
            if(++iterations > MAX_LOOP_ITERATIONS){
                exceeded = 1;
                break;
            } // set flag to true if exceed to stop iterations

            int cmp = 0;
            if(mode == BY_PRICE){
                cmp = compare((const void*)&prices[i], (const void*)&prices[j+1]);
            } else if (mode == BY_NAME){
                cmp = compare((const void*)&names[i], (const void*)&names[j+1]);
            } else{
                cmp = compare((const void*)&categories[i], (const void*)&categories[j+1]);
            }

            if(cmp > 0){ //swap all if out of order
                float tp = prices[j];
                prices[j] = prices[j+1];
                prices[j+1] = tp;

                //swap names safely with manual null
                char tname[MAX_NAME_LENGTH];
                strncpy(tname, names[j], MAX_NAME_LENGTH - 1);
                tname[MAX_NAME_LENGTH - 1] = '\0';

                strncpy(names[j], names[j + 1], MAX_NAME_LENGTH - 1);
                names[j][MAX_NAME_LENGTH - 1] = '\0';

                strncpy(names[j + 1], tname, MAX_NAME_LENGTH - 1);
                names[j + 1][MAX_NAME_LENGTH - 1] = '\0';

                /* swap categories safely */
                char tcat[MAX_CATEGORY_LENGTH];
                strncpy(tcat, categories[j], MAX_CATEGORY_LENGTH - 1);
                tcat[MAX_CATEGORY_LENGTH - 1] = '\0';

                strncpy(categories[j], categories[j + 1], MAX_CATEGORY_LENGTH - 1);
                categories[j][MAX_CATEGORY_LENGTH - 1] = '\0';

                strncpy(categories[j + 1], tcat, MAX_CATEGORY_LENGTH - 1);
                categories[j + 1][MAX_CATEGORY_LENGTH - 1] = '\0';

            }




        }
        
     }
     
}