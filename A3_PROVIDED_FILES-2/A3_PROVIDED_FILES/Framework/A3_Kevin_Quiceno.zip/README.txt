⚠️Whether submitting as a group or individually, every submission must include a README file containing the following information:
1. Kevin Esteban Quiceno 
2. *kevin Esteban Quiceno
3. 6439955
4. Kquic005@fiu.edu
5. do ./autograder_restaurant_management_system.sh with a valid TESTCASES.txt, EXPECTED_OUTPUT.txt. or run batchgrader with zipfile containing copyString.c, findMenuItem.c, calculateSum.c, addMenuItem.c, processOrder.c, sortMenu.c
